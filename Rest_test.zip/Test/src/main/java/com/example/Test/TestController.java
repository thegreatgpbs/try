package com.example.Test;

import java.util.ArrayList;
import java.util.List;

import com.lms.ws.trainer.controller.PathVariable;
import com.lms.ws.trainer.controller.RequestMapping;
import com.lms.ws.trainer.controller.ResponseMessage;
import com.lms.ws.trainer.controller.RestController;
import com.lms.ws.trainer.controller.TrainerAttendance;

@RestController
@RequestMapping("/test")
public class TestController {

	@RequestMapping(value = "/weather/{location}", method = RequestMethod.GET, produces = "application/json")
	public ResponseMessage<WeatherLog> getWeatherLog(@PathVariable String location) {
		List<WeatherLog> logList = new ArrayList<WeatherLog>();
		ResponseMessage<WeatherLog> response = new ResponseMessage<List<WeatherLog>>();

		RestTemplate restTemplate = new RestTemplate();
        WeatherLog weatherLog = new WeatherLog();
        
		try {
			logList = restTemplate.getForObject("https://openweathermap.org/api", WeatherLog.class);
			for(WeatherLog log : logList){
				if(log.getLocation().equalsIgnoreCase(location)){
					weatherLog = log;
				}
			}
			if(logList.size() != 0){
				response.setSuccess(true);
				response.setBody(weatherLog);
				response.setMessage("Weather for " + location);
			} else{
				System.out.println("Failed to retrieve weather log");
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		return response;
	}
}
